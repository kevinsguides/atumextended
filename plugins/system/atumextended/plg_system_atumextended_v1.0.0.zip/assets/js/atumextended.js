console.log('atumextended.js');

//set data-theme to light
document.documentElement.setAttribute('data-theme', 'light');
